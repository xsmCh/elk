package com.itheima.es.domain;

/**
 * creste by itheima.itcast
 */
public interface Response {
    public static final boolean SUCCESS = true;
    public static final int SUCCESS_CODE = 10000;
}
