import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _09fe0e50 = () => import('..\\pages\\user.vue' /* webpackChunkName: "pages_user" */).then(m => m.default || m)
const _70c838aa = () => import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages_user_index" */).then(m => m.default || m)
const _767a643e = () => import('..\\pages\\user\\one.vue' /* webpackChunkName: "pages_user_one" */).then(m => m.default || m)
const _1f805d92 = () => import('..\\pages\\user\\_id.vue' /* webpackChunkName: "pages_user__id" */).then(m => m.default || m)
const _03a80e50 = () => import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */).then(m => m.default || m)
const _54843972 = () => import('..\\pages\\course\\search\\index.vue' /* webpackChunkName: "pages_course_search_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash && document.querySelector(to.hash)) {
        // scroll to anchor by returning the selector
        position = { selector: to.hash }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/user",
			component: _09fe0e50,
			children: [
				{
					path: "",
					component: _70c838aa,
					name: "user"
				},
				{
					path: "one",
					component: _767a643e,
					name: "user-one"
				},
				{
					path: ":id",
					component: _1f805d92,
					name: "user-id"
				}
			]
		},
		{
			path: "/about",
			component: _03a80e50,
			name: "about"
		},
		{
			path: "/course/search",
			component: _54843972,
			name: "course-search"
		}
    ],
    
    
    fallback: false
  })
}
