<template>
  <div>
    one页面
  </div>
</template>
<script>
    export default{
      layout:'test'

    }
</script>
<style>

</style>
