<template>
  <div>
    用户管理首页
  </div>
</template>
<script>
    export default{
      layout:'test'

    }
</script>
<style>

</style>
