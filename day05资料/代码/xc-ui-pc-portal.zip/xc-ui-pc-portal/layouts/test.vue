<template>
  <div>
    这里是头部区域!!!
    <nuxt/>
    这里是尾部区域!!!
  </div>
</template>
<script>
  export default {

  }
</script>
<style>

</style>
