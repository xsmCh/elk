var sysConfig = {
    apiURL: '/openapi',//客户端请求
    staticURL: '/static',
    backApiURL: 'http://www.xuecheng.com/openapi',//服务端请求
    backStaticURL: 'http://www.xuecheng.com/static',
    imgUrl:'http://img.xuecheng.com',
    videoUrl:'http://video.xuecheng.com'
}

module.exports = sysConfig
